function login()
{
    var username=document.getElementById("username").value;
    var password=document.getElementById("password").value;
if (username=="190031815@kluniversity.in" && password=="31815")
{
    alert("login successful");
}
else if (username=="190031686@kluniversity.in" && password=="31686"){
    alert("login successful");
}
else if (username=="190031651@kluniversity.in" && password=="31651"){
    alert("login successful");
}
else{
    alert("login failed");
}
}